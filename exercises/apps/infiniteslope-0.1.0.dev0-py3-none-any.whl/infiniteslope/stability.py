"""Infinite-slope stability on a hillside of constant gradient.

The failure depth is not prescribed.  It emerges as the **critical thickness**
``t_c`` -- the shallowest plane at which the factor of safety reaches one --
following Cruikshank, *Theory of Slope Stability* (PSU G483/583), eq. 2.4.7.

Geometry and sign conventions
-----------------------------
``z``      vertical depth below the land surface, positive downward (m)
``theta``  slope angle from horizontal (degrees)

The soil holds a **uniform degree of saturation** ``S``: every part of the
column is equally wet, and there is no water table.  Two consequences, and
they pull in opposite directions.

The water adds weight, so the bulk density is

    rho = (1 - n) rho_r + n S rho_w

which is the form in Andy's course notes.  Porosity enters *here*, and only
here.  The pore pressure carries no porosity at all:

    u(z) = S rho_w g z cos^2(theta)                            [Cruikshank 2.4.1]

Pressure is a property of the water phase, not a volume-weighted average over
the bulk.  Porosity governs how much water is present, and so how much weight
it adds -- it does not govern the pressure.

``S`` is uniform rather than a water table at some depth, because a water table
at a *fixed depth* leaves everything below it saturated for ever: the deep
limit of ``FS`` is then the fully buoyant one no matter where the table sits,
so draining the hillside relocates the failure deeper instead of stabilising
it.  Being dimensionless and depth-independent, ``S`` survives that limit.

The honest caveat: below full saturation the pore water of a real soil is held
in *tension*, and the pressure is negative rather than a fraction of the
hydrostatic value.  ``S`` here is a proxy for how much positive pore pressure
has built up, not a model of unsaturated flow.

The stresses on a slope-parallel plane at depth ``z`` are

    sigma(z) = W(z) g cos^2(theta)          total normal stress
    tau(z)   = W(z) g sin(theta) cos(theta) driving shear stress

where ``W(z)`` is the mass of the column above unit horizontal area.  The
driving stress carries the **total** (wet) bulk density; the effective normal
stress carries the **buoyant** density ``(1 - n)(rho_r - rho_w)`` below the
water table.  That asymmetry is the whole physics of pore pressure here, and it
is Cruikshank eqs. 2.4.6a and 2.3.15d.
"""

import numpy as np

G = 9.81            # m/s2
RHO_W = 1000.       # kg/m3, fresh water


class InfiniteSlope:
    """A constant-gradient hillside of homogeneous soil.

    Parameters
    ----------
    slope_angle : float
        Hillside gradient, degrees from horizontal.
    cohesion : float
        Effective cohesion of the soil, Pa.  Includes root reinforcement.
    friction_angle : float
        Effective angle of internal friction, degrees.
    saturation : float
        Degree of saturation of the pore space, 0 to 1, uniform with depth.
        ``0`` is dry soil and ``1`` is fully saturated.  Dimensionless, so it
        needs no soil thickness to be defined against.
    grain_density : float
        Density of the solid grains, kg/m3.
    porosity : float
        Void fraction of the soil, 0-1.
    relief : float
        Height of the hillside above its toe, m.  Bounds how deep a
        slope-parallel failure plane can lie and still daylight within the
        hillside; deeper than this, the infinite-slope idealisation has stopped
        applying.
    soil_thickness : float, optional
        Vertical depth to the soil-bedrock contact, m.  ``None`` (the default)
        means soil all the way down.  This is the hook for bedrock: when it is
        set, it bounds the failure depth alongside ``relief``.
    """

    def __init__(self, slope_angle, cohesion, friction_angle,
                 saturation, grain_density=2650., porosity=0.35,
                 relief=20., soil_thickness=None):
        self.slope_angle = float(slope_angle)
        self.cohesion = float(cohesion)
        self.friction_angle = float(friction_angle)
        if not 0. <= float(saturation) <= 1.:
            raise ValueError(
                'saturation is a fraction of the pore space and must lie in '
                f'[0, 1]; got {saturation!r}.  It is not a depth.')
        self.saturation = float(saturation)
        self.grain_density = float(grain_density)
        self.porosity = float(porosity)
        self.relief = float(relief)
        self.soil_thickness = soil_thickness

    # -- densities -------------------------------------------------------
    @property
    def bulk_density(self):
        """Bulk density of the soil at its current saturation, kg/m3.

        ``rho = (1 - n) rho_r + n S rho_w`` -- the form in the course notes.
        Porosity enters here, through the weight of the water present, and
        nowhere else in the model.
        """
        n = self.porosity
        return (1. - n) * self.grain_density + n * self.saturation * RHO_W

    @property
    def saturated_density(self):
        """Bulk density the soil would have at ``S = 1``, kg/m3."""
        n = self.porosity
        return (1. - n) * self.grain_density + n * RHO_W

    @property
    def buoyant_density(self):
        """Submerged bulk density, ``rho_sat - rho_w``  [Cruikshank 2.3.15d].

        Equals ``(1 - n)(rho_r - rho_w)``.  This -- not ``(1 - n) rho_r`` -- is
        what carries the friction below the water table.
        """
        return self.saturated_density - RHO_W

    # -- geometry --------------------------------------------------------
    @property
    def _theta(self):
        return np.radians(self.slope_angle)

    @property
    def failure_depth_bound(self):
        """Deepest slope-parallel plane the hillside can actually supply, m."""
        if self.soil_thickness is None:
            return self.relief
        return min(self.relief, float(self.soil_thickness))

    def column_mass(self, z):
        """Mass per unit horizontal area of the column above depth ``z``, kg/m2."""
        return self.bulk_density * np.asarray(z, dtype=float)

    def pore_pressure(self, z):
        """Pore-fluid pressure on the plane at depth ``z``, Pa  [Cruikshank 2.4.1].

        ``u = S rho_w g z cos^2(theta)``.  No porosity: whatever fraction of
        the bulk volume the water occupies, the pressure it exerts is set by
        the head of water above the plane, not by that fraction.
        """
        z = np.asarray(z, dtype=float)
        return self.saturation * RHO_W * G * z * np.cos(self._theta) ** 2

    # -- stresses and stability -----------------------------------------
    def normal_stress(self, z):
        """Total normal stress on the plane at depth ``z``, Pa."""
        return self.column_mass(z) * G * np.cos(self._theta) ** 2

    def shear_stress(self, z):
        """Driving shear stress on the plane at depth ``z``, Pa."""
        th = self._theta
        return self.column_mass(z) * G * np.sin(th) * np.cos(th)

    def factor_of_safety(self, z):
        """Factor of safety on the slope-parallel plane at depth ``z``.

        ``FS > 1`` stable, ``FS < 1`` unstable, ``FS = 1`` incipient failure.
        """
        z = np.asarray(z, dtype=float)
        effective = self.normal_stress(z) - self.pore_pressure(z)
        resisting = self.cohesion + effective * np.tan(np.radians(self.friction_angle))
        with np.errstate(divide='ignore', invalid='ignore'):
            return resisting / self.shear_stress(z)

    @property
    def deep_limit_factor_of_safety(self):
        """``FS`` as ``z -> infinity``: the cohesionless balance.

        Cohesion is divided by depth and vanishes, so this is what decides
        whether the hillside can fail *at all*.  Because ``m`` is a fraction of
        uniform and dimensionless, saturation survives the limit:

            FS_deep = [1 - S rho_w / rho] tan(phi) / tan(theta)

        ``S = 0`` gives ``tan(phi)/tan(theta)``, the dry angle-of-repose result;
        ``S = 1`` gives the fully buoyant one.  A partly wet hillside sits
        between the two, which an absolute water-table depth cannot express.
        """
        ratio = 1. - self.saturation * RHO_W / self.bulk_density
        return ratio * np.tan(np.radians(self.friction_angle)) / np.tan(self._theta)

    # -- the emergent failure depth --------------------------------------
    @property
    def critical_thickness(self):
        """Shallowest depth at which ``FS = 1``, m  [Cruikshank 2.4.7].

        This is the model's emergent output: it is solved for, never supplied.
        Everything *below* it is also unstable, because ``FS`` decreases
        monotonically with depth for homogeneous soil at uniform saturation.
        Returns ``inf`` when no plane fails at any depth, and ``0.``
        when every plane fails.
        """
        if self.deep_limit_factor_of_safety >= 1.:
            return np.inf                        # strength wins at every depth
        if float(self.factor_of_safety(1e-9)) <= 1.:
            return 0.                            # cohesionless: fails throughout
        lo, hi = 1e-9, 1.
        while float(self.factor_of_safety(hi)) > 1.:
            hi *= 2.
            if hi > 1e9:
                return np.inf
        for _ in range(200):                     # bisection; FS is monotone in z
            mid = 0.5 * (lo + hi)
            if float(self.factor_of_safety(mid)) > 1.:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)

    @property
    def state(self):
        """One of ``'stable'``, ``'unreachable'``, ``'failure'``.

        ``'stable'``       no plane fails at any depth.
        ``'unreachable'``  a failure plane exists, but lies deeper than the
                           hillside can supply -- infinite-slope has stopped
                           applying rather than the slope being safe.
        ``'failure'``      the failure plane lies within the hillside.
        """
        t_c = self.critical_thickness
        if not np.isfinite(t_c):
            return 'stable'
        if t_c > self.failure_depth_bound:
            return 'unreachable'
        return 'failure'

    def summary(self):
        """One-line provenance of the current state, for printing above a result."""
        t_c = self.critical_thickness
        depth = 'none' if not np.isfinite(t_c) else f'{t_c:.2f} m'
        return (f'theta={self.slope_angle:.1f} deg  c={self.cohesion/1e3:.1f} kPa  '
                f'phi={self.friction_angle:.1f} deg  S={self.saturation:.2f}  '
                f'n={self.porosity:.2f}  rho_r={self.grain_density:.0f} kg/m3  '
                f'| FS(deep)={self.deep_limit_factor_of_safety:.3f}  '
                f't_c={depth}  bound={self.failure_depth_bound:.2f} m  -> {self.state}')
