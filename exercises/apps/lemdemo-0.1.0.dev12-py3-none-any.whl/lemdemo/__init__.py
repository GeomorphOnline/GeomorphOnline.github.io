"""A small landscape-evolution model for teaching, built on Landlab."""
from .model import Landscape, relax_limits

__all__ = ["Landscape", "relax_limits"]
__version__ = "0.1.0.dev12"
