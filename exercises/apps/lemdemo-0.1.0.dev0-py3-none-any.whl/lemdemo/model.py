"""Rock uplift, stream-power incision, and linear hillslope diffusion on a raster.

    dz/dt = U - K A^m S^n + D del^2 z

Landlab does the work: ``FlowAccumulator`` (D8, with ``DepressionFinderAndRouter``)
finds the drainage area A and the steepest-descent slope S, ``FastscapeEroder``
takes the incision term implicitly, and ``LinearDiffuser`` takes the diffusion
term. The loop is the one in the 2016 ESCI 4701 class script: uplift, diffuse,
route, erode.

This module adds only what a teaching demo reads off the result: the trunk
stream, or the stream nearest a point, and its long profile; the profile over
a hill crest from valley to valley, with the parabola that has the crest's
curvature; a transect across the ridges and valleys; the curvature of the
surface; and a shaded-relief image.
"""
import numpy as np
from landlab import RasterModelGrid
from landlab.components import FlowAccumulator, FastscapeEroder, LinearDiffuser


class Landscape:
    """A square block of uniformly uplifting rock.

    Parameters
    ----------
    U : float
        Rock uplift rate [m/yr].
    K : float
        Erodibility [m^(1-2m)/yr]; with m = 0.5, [1/yr].
    D : float
        Hillslope diffusivity [m^2/yr].
    m, n : float
        Drainage-area and slope exponents.
    nx : int
        Nodes on a side.
    dx : float
        Node spacing [m].
    open_edges : {"south", "all"}
        Which edges are held at z = 0. The others are closed (no flux).
    deposit : bool
        Whether hillslope diffusion may raise a node. With ``False`` (the
        default) diffusion only erodes: the term is min(D del^2 z, 0), and
        the streams carry off whatever the hillslopes deliver. Landlab's
        ``LinearDiffuser``: "If one couples fluvial detachment-limited
        incision with linear diffusion, the channels will not reach the
        predicted analytical solution unless deposit is set to False."
    seed : int
        Seed for the millimeter-scale roughness of the initial surface.
    """

    def __init__(self, U=1e-3, K=4e-5, D=0.2, m=0.5, n=1.0, nx=100, dx=20.,
                 open_edges="south", deposit=False, seed=0):
        self.grid = g = RasterModelGrid((nx, nx), xy_spacing=dx)
        if open_edges not in ("all", "south"):
            raise ValueError("open_edges must be 'all' or 'south'")
        self._closed = open_edges == "south"
        if self._closed:
            g.set_closed_boundaries_at_grid_edges(True, True, True, False)
        # The 2016 class script's initial surface: up to a millimeter of noise.
        np.random.seed(seed)
        self.z = g.add_field("topographic__elevation",
                             np.random.rand(g.number_of_nodes) / 1000.,
                             at="node")
        self.U, self.m, self.n = U, m, n
        self._deposit = deposit
        self.t = 0.
        self._fa = FlowAccumulator(
            g, flow_director="D8",
            depression_finder="DepressionFinderAndRouter")
        self._sp = FastscapeEroder(g, K_sp=K, m_sp=m, n_sp=n)
        self._D = None
        self.D = D
        # The eight neighbors of every node, for walking up the drainage tree.
        self._nbr = np.hstack((g.adjacent_nodes_at_node,
                               g.diagonal_adjacent_nodes_at_node))
        self._fa.run_one_step()

    # ----------------------------------------------------------- parameters
    @property
    def K(self):
        return float(self._sp.K[0])

    @K.setter
    def K(self, value):
        self._sp.K = value

    @property
    def D(self):
        return self._D

    @D.setter
    def D(self, value):
        if value != self._D:
            self._D = value
            self._df = LinearDiffuser(self.grid, linear_diffusivity=value,
                                      deposit=self._deposit)

    # ----------------------------------------------------------------- time
    def step(self, dt):
        """Advance by ``dt`` years."""
        g = self.grid
        self.z[g.core_nodes] += self.U * dt
        self._df.run_one_step(dt)
        self._fa.run_one_step()
        self._sp.run_one_step(dt)
        self.t += dt

    # ------------------------------------------------------------- readings
    @property
    def elevation(self):
        """Elevation [m] as a (rows, columns) array, south row first.

        A closed edge carries no elevation of its own, so its nodes take the
        value of the row or column of nodes beside them.
        """
        z = self.z.reshape(self.grid.shape).copy()
        if self._closed:
            z[-1, :] = z[-2, :]
            z[:, 0] = z[:, 1]
            z[:, -1] = z[:, -2]
        return z

    @property
    def relief(self):
        return float(self.z.max())

    # ------------------------------------------------- walking the network
    def _upstream(self, node):
        """Nodes from ``node`` up to a head, by the donor of largest drainage area."""
        A = self.grid.at_node["drainage_area"]
        rcv = self.grid.at_node["flow__receiver_node"]
        path = [int(node)]
        while True:
            near = self._nbr[path[-1]]
            near = near[near >= 0]
            donors = near[(rcv[near] == path[-1]) & (near != path[-1])]
            if donors.size == 0:
                return path
            path.append(int(donors[np.argmax(A[donors])]))

    def _downstream(self, node):
        """Nodes from ``node`` down its receivers to where the water leaves."""
        rcv = self.grid.at_node["flow__receiver_node"]
        path = [int(node)]
        while rcv[path[-1]] != path[-1]:
            path.append(int(rcv[path[-1]]))
        return path

    def _along(self, path):
        """What a profile along ``path`` (an array of nodes) reads."""
        g = self.grid
        x, y = g.x_of_node[path], g.y_of_node[path]
        step = np.hypot(np.diff(x), np.diff(y))
        return {"node": path, "x": x, "y": y,
                "distance": np.concatenate(([0.], np.cumsum(step))),
                "z": self.z[path].copy(),
                "area": g.at_node["drainage_area"][path].copy()}

    def _row_col(self, x, y):
        """Row and column of the core node nearest the point (x, y) [m]."""
        g = self.grid
        return (int(min(max(round(y / g.dx), 1), g.shape[0] - 2)),
                int(min(max(round(x / g.dx), 1), g.shape[1] - 2)))

    def trunk(self):
        """The largest stream, from its outlet to its head.

        Starts at the boundary node that receives the most drainage area and
        steps to the upstream neighbor with the largest drainage area until no
        node drains in. Returns a dict of arrays ordered from the head down to
        the outlet: ``node``, ``x`` and ``y`` [m], ``distance`` downstream from
        the head [m], ``z`` [m], and drainage ``area`` [m^2].
        """
        g = self.grid
        bnd = g.boundary_nodes
        outlet = bnd[np.argmax(g.at_node["drainage_area"][bnd])]
        return self._along(np.array(self._upstream(outlet)[::-1]))

    def stream(self, x, y, half_width=3):
        """The stream nearest a point, from its head to where it leaves the block.

        Takes the node of largest drainage area within ``half_width`` nodes
        east, west, north, and south of (x, y) [m], then follows the receivers
        down from it and the donor of largest drainage area up from it.
        Returns what ``trunk`` returns.
        """
        g = self.grid
        i, j = self._row_col(x, y)
        rows = slice(max(i - half_width, 1), min(i + half_width, g.shape[0] - 2) + 1)
        cols = slice(max(j - half_width, 1), min(j + half_width, g.shape[1] - 2) + 1)
        A = g.at_node["drainage_area"].reshape(g.shape)[rows, cols]
        k = np.unravel_index(np.argmax(A), A.shape)
        node = (rows.start + k[0]) * g.shape[1] + cols.start + k[1]
        path = self._upstream(node)[::-1] + self._downstream(node)[1:]
        return self._along(np.array(path))

    def _far_side(self, node):
        """The core neighbors of ``node`` on the side away from its receiver.

        Returns them with the slope down to each [m/m], negative where the
        neighbor is the higher of the two.
        """
        g = self.grid
        rcv = int(g.at_node["flow__receiver_node"][node])
        near = self._nbr[node]
        near = near[near >= 0]
        near = near[g.status_at_node[near] == g.BC_NODE_IS_CORE]
        ex, ny = g.x_of_node[near] - g.x_of_node[node], g.y_of_node[near] - g.y_of_node[node]
        away = (ex * (g.x_of_node[rcv] - g.x_of_node[node])
                + ny * (g.y_of_node[rcv] - g.y_of_node[node])) < 0
        return near[away], ((self.z[node] - self.z[near[away]])
                            / np.hypot(ex[away], ny[away]))

    def hillslope(self, x=None, y=None):
        """The profile over the hill crest above a point, from valley to valley.

        Starts on the node nearest (x, y) [m], or on the highest node if no
        point is given. A node is on a crest if the ground also falls on the
        side away from its receiver; until one is, the walk steps to the
        neighbor on that side that rises most steeply. One side of the
        profile then follows the receivers down from the crest. The other
        leaves by the neighbor on the far side that falls most steeply and
        follows the receivers down from there. Each side ends at the first
        node where del^2 z >= 0.

        Returns a dict of arrays ordered from the far side's end to the near
        side's: ``node``, ``x`` and ``y`` [m], ``s`` along the profile from
        the crest [m], ``z`` [m], drainage ``area`` [m^2], and ``laplacian``
        [1/m]; ``crest``, the index of the crest node; ``curvature``, del^2 z
        at the crest node [1/m]; and ``parabola``, the coefficients (of 1, s,
        and s^2) of the parabola with that curvature, placed by least squares
        on the crest node and the node to each side of it. A crest beside a
        closed edge has one side, and the parabola's vertex is the crest.
        """
        g = self.grid
        lap = self.laplacian().ravel()
        if x is None:
            node = int(g.core_nodes[np.argmax(self.z[g.core_nodes])])
        else:
            i, j = self._row_col(x, y)
            node = i * g.shape[1] + j
        while True:
            far, fall = self._far_side(node)
            if far.size == 0 or fall.max() > 0. or fall.min() >= 0.:
                break
            node = int(far[np.argmin(fall)])

        def side(path):
            """``path`` cut at its first node, past the first, that is not convex."""
            flat = np.flatnonzero(~(lap[path[1:]] < 0))
            return path[:flat[0] + 2] if flat.size else path

        one = side(self._downstream(node))
        two = []
        if far.size and fall.max() > 0.:
            two = side([node] + self._downstream(far[np.argmax(fall)]))[1:]
        out = self._along(np.array(two[::-1] + one))
        out["crest"] = len(two)
        along = out.pop("distance")
        out["s"] = along - along[len(two)]
        out["laplacian"] = lap[out["node"]]
        out["curvature"] = kappa = float(lap[node])
        near = slice(max(len(two) - 1, 0), len(two) + 2)
        s, rest = out["s"][near], out["z"][near] - 0.5 * kappa * out["s"][near]**2
        if two and len(one) > 1:
            slope, top = np.polyfit(s, rest, 1)
        else:
            slope, top = 0., self.z[node]
        out["parabola"] = np.array([top, slope, 0.5 * kappa])
        return out

    def transect(self, row=None):
        """Elevation along one west-east row of nodes (the middle one by default).

        Returns ``x`` [m], ``z`` [m], and the transect's ``y`` [m].
        """
        g = self.grid
        if row is None:
            row = g.shape[0] // 2
        return {"x": g.x_of_node.reshape(g.shape)[row].copy(),
                "z": self.elevation[row].copy(),
                "y": float(g.y_of_node.reshape(g.shape)[row, 0])}

    def laplacian(self):
        """del^2 z [1/m] as a (rows, columns) array; NaN on the edges.

        The five-point form, which is the divergence that ``LinearDiffuser``
        takes on a raster. Beside a closed edge it carries no flux across
        that edge.
        """
        z = self.elevation
        out = np.full(z.shape, np.nan)
        out[1:-1, 1:-1] = (z[1:-1, :-2] + z[1:-1, 2:] + z[:-2, 1:-1]
                           + z[2:, 1:-1] - 4. * z[1:-1, 1:-1]) / self.grid.dx**2
        return out

    def hillshade(self, azimuth=315., altitude=45.):
        """Shaded relief, 0 (dark) to 1 (bright), as a (rows, columns) array."""
        dzdy, dzdx = np.gradient(self.elevation, self.grid.dx)
        az, alt = np.radians(azimuth), np.radians(altitude)
        slope = np.arctan(np.hypot(dzdx, dzdy))
        aspect = np.arctan2(dzdx, dzdy)
        shade = (np.sin(alt) * np.cos(slope)
                 - np.cos(alt) * np.sin(slope) * np.cos(az - aspect))
        return np.clip(shade, 0., 1.)


def relax_limits(now, target, rate):
    """Move axis limits a fraction ``rate`` of the way to ``target``."""
    return tuple(a + rate * (b - a) for a, b in zip(now, target))
