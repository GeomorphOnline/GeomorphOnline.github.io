"""Rock uplift, stream-power incision, and linear hillslope diffusion on a raster.

    dz/dt = U - K A^m S^n + D del^2 z

Landlab does the work: ``FlowAccumulator`` (D8, with ``DepressionFinderAndRouter``)
finds the drainage area A and the steepest-descent slope S, ``FastscapeEroder``
takes the incision term implicitly, and ``LinearDiffuser`` takes the diffusion
term. The loop is the one in the 2016 ESCI 4701 class script: uplift, diffuse,
route, erode.

This module adds only what a teaching demo reads off the result: the trunk
stream and its long profile, a transect across the ridges and valleys, the
curvature of the surface, and a shaded-relief image.
"""
import numpy as np
from landlab import RasterModelGrid
from landlab.components import FlowAccumulator, FastscapeEroder, LinearDiffuser


class Landscape:
    """A square block of uniformly uplifting rock.

    Parameters
    ----------
    U : float
        Rock uplift rate [m/yr].
    K : float
        Erodibility [m^(1-2m)/yr]; with m = 0.5, [1/yr].
    D : float
        Hillslope diffusivity [m^2/yr].
    m, n : float
        Drainage-area and slope exponents.
    nx : int
        Nodes on a side.
    dx : float
        Node spacing [m].
    open_edges : {"south", "all"}
        Which edges are held at z = 0. The others are closed (no flux).
    deposit : bool
        Whether hillslope diffusion may raise a node. With ``False`` (the
        default) diffusion only erodes: the term is min(D del^2 z, 0), and
        the streams carry off whatever the hillslopes deliver. Landlab's
        ``LinearDiffuser``: "If one couples fluvial detachment-limited
        incision with linear diffusion, the channels will not reach the
        predicted analytical solution unless deposit is set to False."
    seed : int
        Seed for the millimeter-scale roughness of the initial surface.
    """

    def __init__(self, U=1e-3, K=4e-5, D=0.2, m=0.5, n=1.0, nx=100, dx=20.,
                 open_edges="south", deposit=False, seed=0):
        self.grid = g = RasterModelGrid((nx, nx), xy_spacing=dx)
        if open_edges not in ("all", "south"):
            raise ValueError("open_edges must be 'all' or 'south'")
        self._closed = open_edges == "south"
        if self._closed:
            g.set_closed_boundaries_at_grid_edges(True, True, True, False)
        # The 2016 class script's initial surface: up to a millimeter of noise.
        np.random.seed(seed)
        self.z = g.add_field("topographic__elevation",
                             np.random.rand(g.number_of_nodes) / 1000.,
                             at="node")
        self.U, self.m, self.n = U, m, n
        self._deposit = deposit
        self.t = 0.
        self._fa = FlowAccumulator(
            g, flow_director="D8",
            depression_finder="DepressionFinderAndRouter")
        self._sp = FastscapeEroder(g, K_sp=K, m_sp=m, n_sp=n)
        self._D = None
        self.D = D
        # The eight neighbors of every node, for walking up the drainage tree.
        self._nbr = np.hstack((g.adjacent_nodes_at_node,
                               g.diagonal_adjacent_nodes_at_node))
        self._fa.run_one_step()

    # ----------------------------------------------------------- parameters
    @property
    def K(self):
        return float(self._sp.K[0])

    @K.setter
    def K(self, value):
        self._sp.K = value

    @property
    def D(self):
        return self._D

    @D.setter
    def D(self, value):
        if value != self._D:
            self._D = value
            self._df = LinearDiffuser(self.grid, linear_diffusivity=value,
                                      deposit=self._deposit)

    # ----------------------------------------------------------------- time
    def step(self, dt):
        """Advance by ``dt`` years."""
        g = self.grid
        self.z[g.core_nodes] += self.U * dt
        self._df.run_one_step(dt)
        self._fa.run_one_step()
        self._sp.run_one_step(dt)
        self.t += dt

    # ------------------------------------------------------------- readings
    @property
    def elevation(self):
        """Elevation [m] as a (rows, columns) array, south row first.

        A closed edge carries no elevation of its own, so its nodes take the
        value of the row or column of nodes beside them.
        """
        z = self.z.reshape(self.grid.shape).copy()
        if self._closed:
            z[-1, :] = z[-2, :]
            z[:, 0] = z[:, 1]
            z[:, -1] = z[:, -2]
        return z

    @property
    def relief(self):
        return float(self.z.max())

    def trunk(self):
        """The largest stream, from its outlet to its head.

        Starts at the boundary node that receives the most drainage area and
        steps to the upstream neighbor with the largest drainage area until no
        node drains in. Returns a dict of arrays ordered from the head down to
        the outlet: ``node``, ``x`` and ``y`` [m], ``distance`` downstream from
        the head [m], ``z`` [m], and drainage ``area`` [m^2].
        """
        g = self.grid
        A = g.at_node["drainage_area"]
        rcv = g.at_node["flow__receiver_node"]
        bnd = g.boundary_nodes
        node = int(bnd[np.argmax(A[bnd])])
        path = [node]
        while True:
            near = self._nbr[node]
            near = near[near >= 0]
            donors = near[(rcv[near] == node) & (near != node)]
            if donors.size == 0:
                break
            node = int(donors[np.argmax(A[donors])])
            path.append(node)
        path = np.array(path[::-1])
        x, y = g.x_of_node[path], g.y_of_node[path]
        step = np.hypot(np.diff(x), np.diff(y))
        return {"node": path, "x": x, "y": y,
                "distance": np.concatenate(([0.], np.cumsum(step))),
                "z": self.z[path].copy(), "area": A[path].copy()}

    def transect(self, row=None):
        """Elevation along one west-east row of nodes (the middle one by default).

        Returns ``x`` [m], ``z`` [m], and the transect's ``y`` [m].
        """
        g = self.grid
        if row is None:
            row = g.shape[0] // 2
        return {"x": g.x_of_node.reshape(g.shape)[row].copy(),
                "z": self.elevation[row].copy(),
                "y": float(g.y_of_node.reshape(g.shape)[row, 0])}

    def laplacian(self):
        """del^2 z [1/m] as a (rows, columns) array; NaN on the edges.

        The five-point form, which is the divergence that ``LinearDiffuser``
        takes on a raster. Beside a closed edge it carries no flux across
        that edge.
        """
        z = self.elevation
        out = np.full(z.shape, np.nan)
        out[1:-1, 1:-1] = (z[1:-1, :-2] + z[1:-1, 2:] + z[:-2, 1:-1]
                           + z[2:, 1:-1] - 4. * z[1:-1, 1:-1]) / self.grid.dx**2
        return out

    def hillshade(self, azimuth=315., altitude=45.):
        """Shaded relief, 0 (dark) to 1 (bright), as a (rows, columns) array."""
        dzdy, dzdx = np.gradient(self.elevation, self.grid.dx)
        az, alt = np.radians(azimuth), np.radians(altitude)
        slope = np.arctan(np.hypot(dzdx, dzdy))
        aspect = np.arctan2(dzdx, dzdy)
        shade = (np.sin(alt) * np.cos(slope)
                 - np.cos(alt) * np.sin(slope) * np.cos(az - aspect))
        return np.clip(shade, 0., 1.)


def relax_limits(now, target, rate):
    """Move axis limits a fraction ``rate`` of the way to ``target``."""
    return tuple(a + rate * (b - a) for a, b in zip(now, target))
