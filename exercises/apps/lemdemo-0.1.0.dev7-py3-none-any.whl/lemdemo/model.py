"""Rock uplift, stream-power incision, and linear hillslope diffusion on a raster.

    dz/dt = U - K A^m S^n + D del^2 z

As built, the diffusion erodes and does not deposit: its term is
min(D del^2 z, 0). ``deposit=True`` gives the equation as written.

Landlab does the work: ``FlowAccumulator`` (D8, with ``DepressionFinderAndRouter``)
finds the drainage area A and the steepest-descent slope S, ``FastscapeEroder``
takes the incision term implicitly, and ``LinearDiffuser`` takes the diffusion
term. The loop is the one in the 2016 ESCI 4701 class script: uplift, diffuse,
route, erode.

This module adds only what a teaching demo reads off the result: the trunk
stream, or the stream nearest a point, and its long profile; the profile over
a hillcrest from valley to valley, with the parabola that has the crest's
curvature; a transect across the ridges and valleys; the curvature of the
surface, and the line along which it is zero (contourpy traces it), which is
the channel-hillslope transition over the whole block; the drainage divides
of the streams that start at a threshold drainage area, and those of them
that are ridgelines; the channels, which start at a threshold drainage area
and no higher than the transition, with their Strahler orders, their
steepness S A^theta, and the drainage density; the fit of S = ks A^(-theta)
to a stream; and a shaded-relief image.
"""
import numpy as np
from contourpy import contour_generator
from landlab import RasterModelGrid
from landlab.components import FlowAccumulator, FastscapeEroder, LinearDiffuser


class Landscape:
    """A square block of uniformly uplifting rock.

    Parameters
    ----------
    U : float
        Rock uplift rate [m/yr].
    K : float
        Erodibility [m^(1-2m)/yr]; with m = 0.5, [1/yr].
    D : float
        Hillslope diffusivity [m^2/yr].
    m, n : float
        Drainage-area and slope exponents, fixed once the landscape is built.
    nx : int
        Nodes on a side.
    dx : float
        Node spacing [m].
    open_edges : {"south", "all"}
        Which edges are held at z = 0. The others are closed (no flux).
    deposit : bool
        Whether hillslope diffusion may raise a node. With ``False`` (the
        default) diffusion only erodes: the term is min(D del^2 z, 0), and
        the streams carry off whatever the hillslopes deliver. Landlab's
        ``LinearDiffuser``: "If one couples fluvial detachment-limited
        incision with linear diffusion, the channels will not reach the
        predicted analytical solution unless deposit is set to False."
    seed : int
        Seed for the millimeter-scale roughness of the initial surface.
    stream_area : float
        Drainage area [m^2] at which a stream starts, for the divides and the
        ridgelines only. The default is 100 cells of 400 m^2.
    channel_area : float
        Drainage area [m^2] below which no channel starts, for ``channels``
        only. The default is 4 cells of 400 m^2.
    """

    def __init__(self, U=1e-3, K=4e-5, D=0.2, m=0.5, n=1.0, nx=100, dx=20.,
                 open_edges="south", deposit=False, seed=0, stream_area=4e4,
                 channel_area=1600.):
        self.grid = g = RasterModelGrid((nx, nx), xy_spacing=dx)
        if open_edges not in ("all", "south"):
            raise ValueError("open_edges must be 'all' or 'south'")
        self._closed = open_edges == "south"
        if self._closed:
            g.set_closed_boundaries_at_grid_edges(True, True, True, False)
        # The 2016 class script's initial surface: up to a millimeter of noise.
        rough = np.random.RandomState(seed).rand(g.number_of_nodes) / 1000.
        self.z = g.add_field("topographic__elevation", rough, at="node")
        self.U, self.m, self.n = U, m, n
        self.stream_area = stream_area
        self.channel_area = channel_area
        self._deposit = deposit
        self.t = 0.
        self._fa = FlowAccumulator(
            g, flow_director="D8",
            depression_finder="DepressionFinderAndRouter")
        self._sp = FastscapeEroder(g, K_sp=K, m_sp=m, n_sp=n)
        self._D = None
        self.D = D
        # The eight neighbors of every node, for walking up the drainage tree.
        self._nbr = np.hstack((g.adjacent_nodes_at_node,
                               g.diagonal_adjacent_nodes_at_node))
        self._fa.run_one_step()
        self._pits = True
        # Landlab writes these in place, as it does the elevation.
        self._area = g.at_node["drainage_area"]
        self._rcv = g.at_node["flow__receiver_node"]
        self._x, self._y = g.x_of_node, g.y_of_node
        self._core = g.status_at_node == g.BC_NODE_IS_CORE
        # Of each node's eight neighbors: which are there and are core nodes,
        # which are there and are not on a closed edge, and how far off each
        # is [m] (1 where there is none, to divide by).
        there = self._nbr >= 0
        self._nbr_core = there & np.asarray(self._core)[self._nbr]
        self._nbr_open = there & (g.status_at_node
                                  != g.BC_NODE_IS_CLOSED)[self._nbr]
        self._nbr_ex = np.where(there, self._x[self._nbr] - self._x[:, None], 0.)
        self._nbr_ny = np.where(there, self._y[self._nbr] - self._y[:, None], 0.)
        self._nbr_reach = np.where(there, np.hypot(self._nbr_ex, self._nbr_ny), 1.)
        # The nodes that have a del^2 z: all but the edges.
        self._x_in = g.x_of_node.reshape(g.shape)[1:-1, 1:-1]
        self._y_in = g.y_of_node.reshape(g.shape)[1:-1, 1:-1]

    # ----------------------------------------------------------- parameters
    @property
    def K(self):
        return float(self._sp.K[0])

    @K.setter
    def K(self, value):
        self._sp.K = value

    @property
    def D(self):
        return self._D

    @D.setter
    def D(self, value):
        if value != self._D:
            self._D = value
            self._df = LinearDiffuser(self.grid, linear_diffusivity=value,
                                      deposit=self._deposit)

    # ----------------------------------------------------------------- time
    def step(self, dt):
        """Advance by ``dt`` years."""
        g = self.grid
        self.z[g.core_nodes] += self.U * dt
        self._df.run_one_step(dt)
        # FlowAccumulator runs its depression finder on every step, pits or
        # no pits. The initial roughness has pits; once the streams have
        # drained them there are none, and the finder repeats the accumulation.
        # It runs once more after the last pit, to clear what it mapped.
        self._fa.flow_director.run_one_step()
        pits = bool(self._fa.pits_present())
        self._fa.accumulate_flow(update_flow_director=False,
                                 update_depression_finder=pits or self._pits)
        self._pits = pits
        self._sp.run_one_step(dt)
        self.t += dt

    # ------------------------------------------------------------- readings
    @property
    def elevation(self):
        """Elevation [m] as a (rows, columns) array, south row first.

        A closed edge carries no elevation of its own, so its nodes take the
        value of the row or column of nodes beside them.
        """
        z = self.z.reshape(self.grid.shape).copy()
        if self._closed:
            z[-1, :] = z[-2, :]
            z[:, 0] = z[:, 1]
            z[:, -1] = z[:, -2]
        return z

    @property
    def relief(self):
        return float(self.z.max())

    # ------------------------------------------------- walking the network
    def _upstream(self, node):
        """Nodes from ``node`` up to a head, by the donor of largest drainage area."""
        A, rcv = self._area, self._rcv
        node = int(node)
        path = [node]
        # Only the starting node can be on the edge.
        near = self._nbr[node]
        near = near[near >= 0]
        while True:
            donors = near[rcv[near] == node]
            if donors.size == 0:
                return path
            node = int(donors[np.argmax(A[donors])])
            path.append(node)
            near = self._nbr[node]

    def _fall(self):
        """Each node's steepest way down the surface as it is: of its eight
        neighbors, the one to which the slope is greatest, or itself where
        none is lower. A closed edge takes no flow.

        ``step`` routes the flow before it erodes, so the receivers that the
        model holds are those of the surface one erosion earlier. They are the
        ones along which the streams were cut. A hillslope is read off the
        surface as it stands.
        """
        z, nbr = self.z, self._nbr
        node = np.arange(z.size)
        slope = np.where(self._nbr_open, (z[:, None] - z[nbr]) / self._nbr_reach,
                         -np.inf)
        k = slope.argmax(axis=1)
        return np.where(slope[node, k] > 0., nbr[node, k], node)

    def _downstream(self, node, rcv=None):
        """Nodes from ``node`` down its receivers to where the water leaves."""
        rcv = self._rcv if rcv is None else rcv
        path = [int(node)]
        while rcv[path[-1]] != path[-1]:
            path.append(int(rcv[path[-1]]))
        return path

    def _along(self, path):
        """What a profile along ``path`` (an array of nodes) reads."""
        x, y = self._x[path], self._y[path]
        step = np.hypot(np.diff(x), np.diff(y))
        return {"node": path, "x": x, "y": y,
                "distance": np.concatenate(([0.], np.cumsum(step))),
                "z": self.z[path].copy(),
                "area": self._area[path].copy()}

    def _stream(self, path):
        """What a stream along ``path`` (an array of nodes, head first) reads."""
        out = self._along(path)
        out["slope"] = np.append(-np.diff(out["z"]) / np.diff(out["distance"]),
                                 np.nan)
        # argmin of a boolean array is its first False.
        out["transition"] = int(np.argmin(self.laplacian().ravel()[path] < 0))
        return out

    def _row_col(self, x, y):
        """Row and column of the core node nearest the point (x, y) [m]."""
        g = self.grid
        return (int(min(max(round(y / g.dx), 1), g.shape[0] - 2)),
                int(min(max(round(x / g.dx), 1), g.shape[1] - 2)))

    def trunk(self):
        """The largest stream, from its head to its outlet.

        Starts at the boundary node that receives the most drainage area and
        steps to the upstream neighbor with the largest drainage area until no
        node drains in. Returns a dict of arrays ordered from the head down to
        the outlet: ``node``, ``x`` and ``y`` [m], ``distance`` downstream from
        the head [m], ``z`` [m], drainage ``area`` [m^2], and ``slope`` [m/m],
        the fall to the next node down the stream over the distance to it (NaN
        at the outlet, which has no node below it). ``transition`` is the
        index of the first node from the head where del^2 z >= 0. Diffusion
        erodes only where the surface is convex, so the hillslope is above it.
        """
        bnd = self.grid.boundary_nodes
        outlet = bnd[np.argmax(self._area[bnd])]
        return self._stream(np.array(self._upstream(outlet)[::-1]))

    def stream(self, x, y, half_width=3):
        """The stream nearest a point, from its head to where it leaves the block.

        Takes the node of largest drainage area within ``half_width`` nodes
        east, west, north, and south of (x, y) [m], then follows the receivers
        down from it and the donor of largest drainage area up from it.
        Returns what ``trunk`` returns.
        """
        g = self.grid
        i, j = self._row_col(x, y)
        rows = slice(max(i - half_width, 1), min(i + half_width, g.shape[0] - 2) + 1)
        cols = slice(max(j - half_width, 1), min(j + half_width, g.shape[1] - 2) + 1)
        A = self._area.reshape(g.shape)[rows, cols]
        k = np.unravel_index(np.argmax(A), A.shape)
        node = (rows.start + k[0]) * g.shape[1] + cols.start + k[1]
        path = self._upstream(node)[::-1] + self._downstream(node)[1:]
        return self._stream(np.array(path))

    def _far_side(self, node, rcv=None):
        """The core neighbors of ``node`` on the side away from its receiver.

        Returns them with the slope down to each [m/m], negative where the
        neighbor is the higher of the two.
        """
        x, y = self._x, self._y
        rcv = int((self._rcv if rcv is None else rcv)[node])
        near = self._nbr[node]
        near = near[near >= 0]
        near = near[self._core[near]]
        ex, ny = x[near] - x[node], y[near] - y[node]
        away = (ex * (x[rcv] - x[node]) + ny * (y[rcv] - y[node])) < 0
        return near[away], ((self.z[node] - self.z[near[away]])
                            / np.hypot(ex[away], ny[away]))

    def _crests(self, rcv=None):
        """Whether each node is on a crest: the ground also falls on the side
        away from its receiver, or that side is a closed edge."""
        x, y, z = self._x, self._y, self.z
        rcv = self._rcv if rcv is None else rcv
        away = self._nbr_core & ((self._nbr_ex * (x[rcv] - x)[:, None]
                                  + self._nbr_ny * (y[rcv] - y)[:, None]) < 0)
        falls = away & (z[:, None] > z[self._nbr])
        return np.asarray(self._core) & (falls.any(axis=1) | ~away.any(axis=1))

    def hillslope(self, x=None, y=None):
        """The profile over the hillcrest nearest a point, from valley to valley.

        Starts on the crest node nearest (x, y) [m], or on the highest node
        if no point is given. A node is on a crest if the ground also falls
        on the side away from its receiver. Here a node's receiver is its
        steepest way down the surface as it stands (``_fall``), which at a few
        nodes is not the receiver that the last step eroded along. Where no
        node is on a crest (a plane), the
        walk starts on the node nearest the point and steps to the
        neighbor on that side that rises most steeply. One side of the
        profile then follows the receivers down from the crest. The other
        leaves by the neighbor on the far side that falls most steeply and
        follows the receivers down from there. Each side ends at the first
        node where del^2 z >= 0.

        Returns a dict of arrays ordered from the far side's end to the near
        side's: ``node``, ``x`` and ``y`` [m], ``s`` along the profile from
        the crest [m], ``z`` [m], drainage ``area`` [m^2], and ``laplacian``
        [1/m]; ``crest``, the index of the crest node; ``curvature``, del^2 z
        at the crest node [1/m]; and ``parabola``, the coefficients (of 1, s,
        and s^2) of the parabola with that curvature, placed by least squares
        on the crest node and the node to each side of it. A crest beside a
        closed edge has one side, and the parabola's vertex is the crest.
        """
        g = self.grid
        lap = self.laplacian().ravel()
        down = self._fall()
        if x is None:
            node = int(g.core_nodes[np.argmax(self.z[g.core_nodes])])
        else:
            crest = np.flatnonzero(self._crests(down))
            if crest.size:
                node = int(crest[np.argmin(np.hypot(self._x[crest] - x,
                                                    self._y[crest] - y))])
            else:
                i, j = self._row_col(x, y)
                node = i * g.shape[1] + j
        while True:
            far, fall = self._far_side(node, down)
            if far.size == 0 or fall.max() > 0. or fall.min() >= 0.:
                break
            node = int(far[np.argmin(fall)])

        def side(path):
            """``path`` cut at its first node, past the first, that is not convex."""
            flat = np.flatnonzero(~(lap[path[1:]] < 0))
            return path[:flat[0] + 2] if flat.size else path

        one = side(self._downstream(node, down))
        two = []
        if far.size and fall.max() > 0.:
            two = side([node] + self._downstream(far[np.argmax(fall)], down))[1:]
        out = self._along(np.array(two[::-1] + one))
        out["crest"] = len(two)
        along = out.pop("distance")
        out["s"] = along - along[len(two)]
        out["laplacian"] = lap[out["node"]]
        out["curvature"] = kappa = float(lap[node])
        near = slice(max(len(two) - 1, 0), len(two) + 2)
        s, rest = out["s"][near], out["z"][near] - 0.5 * kappa * out["s"][near]**2
        if two and len(one) > 1:
            slope, top = np.polyfit(s, rest, 1)
        else:
            slope, top = 0., self.z[node]
        out["parabola"] = np.array([top, slope, 0.5 * kappa])
        return out

    def transect(self, row=None):
        """Elevation along one west-east row of nodes (the middle one by default).

        Returns ``x`` [m], ``z`` [m], and the transect's ``y`` [m].
        """
        g = self.grid
        if row is None:
            row = g.shape[0] // 2
        return {"x": g.x_of_node.reshape(g.shape)[row].copy(),
                "z": self.elevation[row].copy(),
                "y": float(g.y_of_node.reshape(g.shape)[row, 0])}

    def laplacian(self):
        """del^2 z [1/m] as a (rows, columns) array; NaN on the edges.

        The five-point form, which is the divergence that ``LinearDiffuser``
        takes on a raster. Beside a closed edge it carries no flux across
        that edge.
        """
        z = self.elevation
        out = np.full(z.shape, np.nan)
        out[1:-1, 1:-1] = (z[1:-1, :-2] + z[1:-1, 2:] + z[:-2, 1:-1]
                           + z[2:, 1:-1] - 4. * z[1:-1, 1:-1]) / self.grid.dx**2
        return out

    def transition_line(self):
        """The line del^2 z = 0: the channel-hillslope transition over the block.

        The surface is convex on one side of it and not on the other, so a
        stream's ``transition`` is its first node across it from the head. The
        line is the zero level of ``laplacian()``, found by linear
        interpolation along the grid's edges between the nodes that have a
        del^2 z. Nothing is smoothed and no piece is dropped, however short.

        Returns a dict of two arrays, ``x`` and ``y`` [m]. The line comes in
        many pieces, and a NaN in both arrays separates one from the next.
        """
        lines = contour_generator(
            self._x_in, self._y_in, self.laplacian()[1:-1, 1:-1],
            line_type="ChunkCombinedNan").lines(0.)[0][0]
        if lines is None:                      # no curvature of either sign
            lines = np.empty((0, 2))
        return {"x": lines[:, 0].copy(), "y": lines[:, 1].copy()}

    def channels(self, order=False, theta=None):
        """The channels, as links from each channel node to its receiver.

        A channel starts where the drainage area is at least ``channel_area``
        and the surface has rolled over (del^2 z >= 0), and every node below
        a channel node is one: a threshold drainage area, clipped upstream to
        the channel-hillslope transition.

        Returns a dict of three (links, 2) arrays: ``node``, a channel node
        and its receiver, and ``x`` and ``y`` [m], the link's two ends. With
        ``order``, also ``order``, the Strahler order of each link's channel
        node: 1 at a head; where channels meet, the highest order among them,
        and one more if two or more of them have it. With ``theta``, also
        ``steepness``, each link's S A^theta [m^(2 theta)]: its slope times
        its channel node's drainage area to that power.
        """
        rcv = self._rcv
        channel = ((self.laplacian().ravel() >= 0.)
                   & np.asarray(self._area >= self.channel_area))
        down = rcv
        for _ in range(rcv.size.bit_length()):   # a receiver's receiver, doubled
            channel[down[channel]] = True
            down = down[down]
        a = np.flatnonzero(channel & (rcv != np.arange(rcv.size)))
        node = np.column_stack((a, rcv[a]))
        out = {"node": node, "x": self._x[node], "y": self._y[node]}
        if order:
            # A donor drains less than its receiver: by area, heads come first.
            down = rcv.tolist()
            top, ties, strahler = ([0] * rcv.size for _ in range(3))
            for k in a[np.argsort(self._area[a], kind="stable")].tolist():
                mine = strahler[k] = top[k] + (ties[k] > 1) if top[k] else 1
                r = down[k]
                if mine > top[r]:
                    top[r], ties[r] = mine, 1
                elif mine == top[r]:
                    ties[r] += 1
            out["order"] = np.array(strahler)[a]
        if theta is not None:
            fall = self.z[a] - self.z[rcv[a]]
            reach = np.hypot(out["x"][:, 1] - out["x"][:, 0],
                             out["y"][:, 1] - out["y"][:, 0])
            out["steepness"] = fall / reach * self._area[a]**theta
        return out

    @staticmethod
    def steepness(profile, theta=0.5):
        """Fit S = ks A^(-theta) to a stream's slope and drainage area.

        ``profile`` is what ``trunk`` or ``stream`` returns. The fit takes
        its nodes from the channel-hillslope transition down, less the last
        link, which ends on the open edge, where diffusion also erodes. It is
        by least squares on the logarithms.

        Returns a dict: ``ks`` [m^(2 theta)] and ``theta``, with both free;
        ``ksn`` [m^(2 theta)], with the concavity held at the ``theta`` given
        (the mean of log(S A^theta)); and ``area``, the two ends of the
        fitted reach [m^2]. NaN where fewer than two nodes have a slope
        greater than zero.
        """
        A = profile["area"][profile["transition"]:-2]
        S = profile["slope"][profile["transition"]:-2]
        ok = S > 0.
        A, S = A[ok], S[ok]
        if A.size < 2 or A.min() == A.max():
            return {"ks": np.nan, "theta": np.nan, "ksn": np.nan,
                    "area": np.full(2, np.nan)}
        slope, top = np.polyfit(np.log(A), np.log(S), 1)
        return {"ks": float(np.exp(top)), "theta": float(-slope),
                "ksn": float(np.exp(np.mean(np.log(S) + theta * np.log(A)))),
                "area": np.array([A.min(), A.max()])}

    def drainage_density(self):
        """Channel length over the area of the block [1/m]: the summed length
        of the links of ``channels`` over the area of the core nodes."""
        c = self.channels()
        length = np.hypot(c["x"][:, 1] - c["x"][:, 0],
                          c["y"][:, 1] - c["y"][:, 0]).sum()
        return float(length / (np.count_nonzero(self._core) * self.grid.dx**2))

    def _segments(self):
        """The stream segment that each node first drains to; -1 where none.

        A stream node is a node whose drainage area is at least
        ``stream_area``, or any node below one. A segment runs from a stream's
        head, or from a confluence, down to the node above the next
        confluence, and goes by its first node. A node on a stream is in its
        own segment.
        """
        rcv = self._rcv
        node = np.arange(rcv.size)
        hops = range(rcv.size.bit_length())    # 2^hops outruns any flow path
        stream = np.asarray(self._area >= self.stream_area) & np.asarray(self._core)
        down = rcv
        for _ in hops:                         # a receiver's receiver, doubled
            stream[down[stream]] = True
            down = down[down]
        flows = stream & (rcv != node)
        donors = np.bincount(rcv[flows], minlength=rcv.size)
        up = node.copy()
        up[rcv[flows]] = node[flows]           # the stream donor, where it is one
        # Down a hillslope to its stream, and up the stream to its first node.
        up = np.where(stream, np.where(donors == 1, up, node), rcv)
        for _ in hops:
            up = up[up]
        return np.where(stream[up], up, -1)

    def divides(self):
        """The drainage divides, on the edges of the cells.

        After Scherler and Schwanghart (2020, doi:10.5194/esurf-8-245-2020):
        divides are the boundaries of the basins of a stream network, and lie
        on the edges between nodes. They are not ordered here. Two nodes side
        by side in a row or a column are parted by a divide if they first
        drain to different stream segments, or if only one of them drains to
        a stream at all, unless one of the two drains into the other. Each
        tributary's basin is then outlined, as is the ground that drains to
        the reach between two confluences. The edges of the block are not
        drawn. Nothing is smoothed and no piece is dropped, however short:
        the divides are as many as the streams, and ``stream_area`` sets
        where those start.

        Returns a dict of three (pieces, 2) arrays: ``node``, the two nodes
        that a piece parts, and ``x`` and ``y`` [m], its two ends. A piece is
        one edge of a cell, midway between its two nodes.
        """
        return self._pieces(self._segments())

    def _pieces(self, label):
        """The divide pieces between the segments in ``label``."""
        g = self.grid
        rcv, core = self._rcv, self._core
        idx = np.arange(g.number_of_nodes).reshape(g.shape)
        half = g.dx / 2.
        node, x, y = [], [], []
        # Neighbors along a row, which a north-south piece parts; then along
        # a column.
        for a, b, along_row in ((idx[:, :-1].ravel(), idx[:, 1:].ravel(), True),
                                (idx[:-1].ravel(), idx[1:].ravel(), False)):
            keep = ((label[a] != label[b]) & core[a] & core[b]
                    & (rcv[a] != b) & (rcv[b] != a))
            a, b = a[keep], b[keep]
            mid = np.column_stack((self._x[a] + self._x[b],
                                   self._y[a] + self._y[b])) / 2.
            ends = np.array([-half, half])
            node.append(np.column_stack((a, b)))
            x.append(mid[:, :1] + (0. * ends if along_row else ends))
            y.append(mid[:, 1:] + (ends if along_row else 0. * ends))
        return {"node": np.vstack(node), "x": np.vstack(x), "y": np.vstack(y)}

    def ridgelines(self):
        """The divides that are ridges, as ``divides`` returns them.

        A divide piece between a reach and the reach below it, or between a
        tributary and the stream it joins, runs down a hillside to their
        confluence and is no ridge. These are left out: a piece stays unless
        the two segments it parts lie on one flow path.
        """
        label, rcv = self._segments(), self._rcv
        d = self._pieces(label)
        a, b = label[d["node"]].T
        both = (a >= 0) & (b >= 0)
        one_path = np.zeros(a.size, dtype=bool)
        # A segment goes by its first node: walk down from each and look for
        # the other.
        for start, other in ((a[both], b[both]), (b[both], a[both])):
            met = np.zeros(start.size, dtype=bool)
            at = start
            while True:
                below = rcv[at]
                if np.array_equal(below, at):
                    break
                at = below
                met |= at == other
            one_path[both] |= met
        return {k: v[~one_path] for k, v in d.items()}

    def hillshade(self, azimuth=315., altitude=45.):
        """Shaded relief, 0 (dark) to 1 (bright), as a (rows, columns) array."""
        dzdy, dzdx = np.gradient(self.elevation, self.grid.dx)
        az, alt = np.radians(azimuth), np.radians(altitude)
        # The unit normal (-dz/dx, -dz/dy, 1) / |.| dotted with the sun's direction.
        shade = ((np.sin(alt) - np.cos(alt) * (np.sin(az) * dzdx + np.cos(az) * dzdy))
                 / np.sqrt(1. + dzdx**2 + dzdy**2))
        return np.clip(shade, 0., 1.)


def relax_limits(now, target, rate):
    """Move axis limits a fraction ``rate`` of the way to ``target``."""
    return tuple(a + rate * (b - a) for a, b in zip(now, target))
