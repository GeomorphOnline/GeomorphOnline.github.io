movie_path: str
